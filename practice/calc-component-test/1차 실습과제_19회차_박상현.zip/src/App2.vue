<script setup>
import Calc2 from './components/Calc2.vue'
</script>
<template>
  <div>
    <Calc2 />
  </div>
</template>

<style scoped></style>
