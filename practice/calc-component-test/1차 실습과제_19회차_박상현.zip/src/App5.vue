<script setup>
import Calc5 from './components/Calc5.vue'
</script>
<template>
  <div>
    <Calc5 />
  </div>
</template>

<style scoped></style>
