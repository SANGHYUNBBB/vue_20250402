<script setup>
import Calc3 from './components/Calc3.vue'
</script>
<template>
  <div>
    <Calc3 />
  </div>
</template>

<style scoped></style>
