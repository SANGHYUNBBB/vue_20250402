<script setup>
import Calc4 from './components/Calc4.vue'
</script>
<template>
  <div>
    <Calc4 />
  </div>
</template>

<style scoped></style>
