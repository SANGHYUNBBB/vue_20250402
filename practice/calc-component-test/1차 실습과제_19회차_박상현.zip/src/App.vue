<script setup>
import Calc from './components/Calc.vue'
</script>
<template>
  <div>
    <Calc />
  </div>
</template>

<style scoped></style>
